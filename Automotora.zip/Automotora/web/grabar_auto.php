<?php

include_once '../controlador/DaoAuto.php';
include_once '../modelo/Auto.php';

$patente=$_POST["txtPatente"];
$duenho=$_POST["txtDuenho"];
$modelo=$_POST["txtModelo"];
$marca=$_POST["txtMarca"];
$anho=$_POST["txtAnho"];

$auto=new Auto();
$auto->setPatente($patente);
$auto->setDuenho($duenho);
$auto->setModelo($modelo);
$auto->setMarca($marca);
$auto->setAnho($anho);

$dao=new DaoAuto();
$filas_afectadas=$dao->Grabar($auto);
if ($filas_afectadas>0){
    echo 'Grabo';
} else {
echo 'No Grabo';    
}