<?php


class Auto {
    private $patente;
    private $duenho;
    private $modelo;
    private $marca;
    private $anho;
    
    function __construct() {
        
    }
    
    function getPatente() {
        return $this->patente;
    }

    function getDuenho() {
        return $this->duenho;
    }

    function getModelo() {
        return $this->modelo;
    }

    function getMarca() {
        return $this->marca;
    }

    function getAnho() {
        return $this->anho;
    }

    function setPatente($patente) {
        $this->patente = $patente;
    }

    function setDuenho($duenho) {
        $this->duenho = $duenho;
    }

    function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    function setMarca($marca) {
        $this->marca = $marca;
    }

    function setAnho($anho) {
        $this->anho = $anho;
    }
    
    

}
